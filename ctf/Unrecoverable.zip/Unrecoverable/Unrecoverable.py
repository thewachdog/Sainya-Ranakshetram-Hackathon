from os import remove, urandom, path
import sys
import random
def driver(passes):
    location = input("Enter full path of file you want to delete: ").strip()
    if path.exists(location):
        if input(f"Do you REALLY want to remove {location} ? This action cannot be undone ... (Y/N) ").lower() != 'y':
            return
        else:
            filePointer = open(location, "wb")
            fileSize = path.getsize(location)
            print("Removing file ...")
            for i in range(passes):
                nulls(filePointer, fileSize)
                ones(filePointer, fileSize)
                randum(filePointer, fileSize)
                nulls(filePointer, fileSize)
            filePointer.close()
            removeFile(location)
            print("The file has removed successfully.")
    else:
        print("File not found.")
def nulls(filePointer, fileSize):
    try:
        filePointer.write(b"\x00"*fileSize)
    except Exception as e:
        print("Cannot write nulls to the file due to error: ",e)
def ones(filePointer, fileSize):
    try:
        filePointer.write(b"\x01"*fileSize)
    except Exception as e:
        print("Cannot write ones to the file due to error: ",e)
def randum(filePointer, fileSize):
    try:
        filePointer.write(urandom(fileSize))
    except Exception as e:
        print("Cannot write randoms to the file due to error: ",e)
def removeFile(location):
    try:
        remove(location)
    except Exception as e:
        print("Cannot remove file due to error: ", e)  
passes = random.randint(14,20)
driver(passes)
