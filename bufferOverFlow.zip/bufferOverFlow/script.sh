#/bin/bash

echo 11 | ./a.out
